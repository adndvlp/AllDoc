import csv
import logging
from datetime import timedelta
from pathlib import Path
import pendulum
from airflow.sdk import DAG, dag, task, task_group, TaskGroup, get_current_context, Variable, Connection, Asset, Param
from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.providers.standard.operators.bash import BashOperator
from airflow.providers.standard.operators.python import PythonOperator

with DAG(
    dag_id="alldoc_resumen_ventas",
    start_date=pendulum.datetime(2026, 9, 1, tz="UTC"),
    schedule=None,
    catchup=False,
) as demo:
    @task
    def extraer():
        with open("/tmp/alldoc_airflow/orders.csv") as f:
            return list(csv.DictReader(f))
    @task
    def transformar(filas):
        completados = [r for r in filas if r["status"] == "completed"]
        return {"pedidos":len(completados), "ventas":sum(int(r["amount"]) for r in completados)}
    @task
    def publicar(resumen):
        if resumen["pedidos"] == 0:
            raise ValueError("Sin pedidos")
        import json
        Path("/tmp/alldoc_airflow/resumen.json").write_text(json.dumps(resumen))
    publicar(transformar(extraer()))
