import csv
import logging
from datetime import timedelta
from pathlib import Path
import pendulum
from airflow.sdk import DAG, dag, task, task_group, TaskGroup, get_current_context, Variable, Connection, Asset, Param
from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.providers.standard.operators.bash import BashOperator
from airflow.providers.standard.operators.python import PythonOperator

with DAG(
    dag_id="alldoc_ejemplo",
    start_date=pendulum.datetime(2026, 9, 1, tz="UTC"),
    schedule=None,
    catchup=False,
) as demo:
    pass
