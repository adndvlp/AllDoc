# Preparar el modelo en Power BI Desktop

En Windows, importa cada CSV desde **Inicio → Obtener datos → Texto o CSV**. Selecciona UTF-8 y coma como delimitador. Usa el nombre del archivo sin extensión para cada consulta.

En Power Query asigna números enteros a los identificadores y a Cantidad, fechas a Fecha, Envio y MesInicio, y número decimal fijo a Precio, Costo y Meta. Conserva como texto los campos de nombres, país, ciudad, categoría y estado. Las celdas vacías representan valores nulos.

Configura todas las columnas de Sucios como texto y desactiva su carga al modelo. Conserva PresupuestoAncho para las fichas de transformación y Accesos para la práctica de seguridad dinámica.

**Preparación del modelo**

En vista Modelo crea relaciones activas `Clientes[ClienteID] (1) → Pedidos[ClienteID] (*)` y `Productos[ProductoID] (1) → Pedidos[ProductoID] (*)`, con filtro único desde dimensión a hechos. Crea la siguiente tabla DAX desde Modelado > Nueva tabla (el código se explica en el grupo de calendario):

```dax
Calendario = CALENDAR(DATE(2025,1,1), DATE(2026,12,31))
```

Marca `Calendario` como tabla de fechas usando `Date`; relaciona `Calendario[Date] (1)` con `Pedidos[Fecha] (*)` y `Metas[MesInicio] (*)` en dirección única. Crea también una relación **inactiva** con `Pedidos[Envio]` para los ejemplos correspondientes. Aunque Metas solo tiene dos filas, fija la cardinalidad 1:* con Calendario en el lado 1. Las metas se interpretan por mes, no como objetivos diarios. Crea las columnas de calendario cuando llegues al grupo correspondiente (Año, Mes, MesN, AñoMes, AñoMesN); desactiva la fecha automática si usas la dimensión común. Las tablas auxiliares quedan desconectadas.

**Medidas de referencia**

Crea cada medida por separado mediante Modelado > Nueva medida, en la tabla Pedidos; las explicaciones aparecen en sus grupos respectivos. No crees dos medidas con el mismo nombre; cada ejemplo alternativo se crea con un nombre distinto o reemplaza temporalmente la definición. Salvo indicación, evalúa sin filtros adicionales, utilizando tarjetas para escalares, tablas o matrices para resultados por dimensión. En los ejemplos que crean tablas o columnas, usa Nueva tabla o Nueva columna, no Nueva medida. Las medidas se escriben entre corchetes; las columnas con `Tabla[Columna]`. Usa `Calendario[AñoMes]` ordenado por `Calendario[AñoMesN]` para mostrar meses.

```dax
Importe = SUMX(Pedidos, Pedidos[Cantidad] * Pedidos[Precio])
Ventas = CALCULATE([Importe], Pedidos[Estado] = "completed")
Pedidos total = COUNTROWS(Pedidos)
Pedidos completados = CALCULATE([Pedidos total], Pedidos[Estado] = "completed")
Ticket = DIVIDE([Ventas], [Pedidos completados])
Objetivo = SUM(Metas[Meta])
```

Controles sin filtros: 8 pedidos, 7 completados, importe 1150, ventas completadas 1100, ticket 157.14 redondeado. México 820, España 280; Ana 520, Luis 280, Marta 300, Diego sin ventas. Tecnología 650, Muebles 450. Enero 2026: 200; febrero 2026: 600; enero 2025: 100; febrero 2025: 200. Las cifras monetarias están en una sola moneda ficticia. Las fórmulas de ventas sustituyen cualquier filtro directo de Estado por `completed`; si se requiere intersectarlo, usa `KEEPFILTERS`.

Los ejemplos de limpieza usan la consulta auxiliar original y los de servicio/infraestructura requieren los recursos explícitamente indicados; no se afirma que esos recursos existan. En cada ejemplo independiente vuelve al estado inicial si has aplicado pasos de otro ejemplo.
