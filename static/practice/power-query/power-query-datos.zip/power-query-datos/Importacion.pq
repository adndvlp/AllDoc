#table(type table [id=text, importe=text, fecha=text],
    {{"1", "1.234,50", "31/01/2026"}, {"2", "N/D", "01/02/2026"}, {"3", "25,00", "02/02/2026"}})
