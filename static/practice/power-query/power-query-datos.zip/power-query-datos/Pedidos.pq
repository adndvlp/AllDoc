#table(
    type table [id=Int64.Type, cliente=Int64.Type, fecha=date, estado=text, importe=number, canal=nullable text],
    {
        {101, 1, #date(2026,1,5), "completado", 100, "Web"},
        {102, 1, #date(2026,1,20), "completado", 200, "Tienda"},
        {103, 2, #date(2026,1,20), "cancelado", 80, "Web"},
        {104, 2, #date(2026,2,3), "completado", 150, "Web"},
        {105, 3, #date(2026,2,3), "completado", 150, null},
        {106, 3, #date(2026,2,10), "pendiente", 50, "Tienda"},
        {107, 1, #date(2026,2,18), "completado", 300, "Web"}
    }
)
