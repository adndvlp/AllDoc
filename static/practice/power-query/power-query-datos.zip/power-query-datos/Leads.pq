#table(
    type table [id=Int64.Type, correo=nullable text, origen=text, fecha=date],
    {
        {1, " ANA@ejemplo.com ", "Ads", #date(2026,1,2)},
        {2, "ana@ejemplo.com", "Web", #date(2026,1,4)},
        {3, "luis@ejemplo.com", "Ads", #date(2026,1,5)},
        {4, "luis@ejemplo.com", "Web", #date(2026,1,6)},
        {5, null, "Web", #date(2026,1,7)},
        {6, "", "Ads", #date(2026,1,8)}
    }
)
