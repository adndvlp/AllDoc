#table(type table [categoria=text, Ene=number, Feb=number],
    {{"Electrónica", 400, 500}, {"Hogar", 200, 300}})
