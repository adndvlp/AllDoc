#table(
    type table [cliente=Int64.Type, nombre=text, pais=nullable text, alta=date],
    {
        {1, "Ana", "México", #date(2025,12,20)},
        {2, "Luis", "México", #date(2026,1,1)},
        {3, "Marta", "España", #date(2026,1,15)},
        {4, "Diego", null, #date(2026,2,1)}
    }
)
