select * from {{ ref('int_completed_orders') }}
