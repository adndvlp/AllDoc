select c.customer_id, c.name, c.country,
       coalesce(sum(o.amount),0) as revenue,
       count(o.order_id) as order_count
from {{ ref('dim_customers') }} c
left join {{ ref('fct_orders') }} o on c.customer_id = o.customer_id
group by c.customer_id, c.name, c.country
