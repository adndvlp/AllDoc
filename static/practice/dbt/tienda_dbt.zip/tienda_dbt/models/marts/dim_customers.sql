select customer_id, name, coalesce(country, 'Unknown') as country
from {{ ref('stg_customers') }}
