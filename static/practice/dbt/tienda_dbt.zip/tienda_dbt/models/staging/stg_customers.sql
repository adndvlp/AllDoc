select customer_id, name, country, updated_at
from {{ source('shop', 'customers') }}
