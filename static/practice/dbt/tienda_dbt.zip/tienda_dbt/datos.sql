create schema if not exists raw;
create table raw.customers (
  customer_id integer primary key,
  name text not null,
  country text,
  updated_at timestamp not null
);
create table raw.orders (
  order_id integer primary key,
  customer_id integer not null references raw.customers(customer_id),
  order_date date not null,
  amount numeric(12,2) not null,
  status text not null,
  updated_at timestamp not null
);
insert into raw.customers values
(1,'Ana','MX','2026-01-01 08:00'),
(2,'Luis','MX','2026-01-01 09:00'),
(3,'Marta','ES','2026-01-02 08:00'),
(4,'Diego',null,'2026-01-02 09:00');
insert into raw.orders values
(101,1,'2026-01-03',100,'completed','2026-01-03 10:00'),
(102,1,'2026-01-05',50,'completed','2026-01-05 10:00'),
(103,2,'2026-01-05',200,'completed','2026-01-05 11:00'),
(104,2,'2026-01-07',80,'cancelled','2026-01-07 10:00'),
(105,3,'2026-02-01',150,'completed','2026-02-01 10:00');
