# Preparar los datos en Tableau

Abre primero `ventas.csv` con **Connect → Text File**. Usa UTF-8, coma como delimitador y la primera fila como encabezados.

Comprueba que `Fecha` y `Entrega` sean fechas y que `Unidades`, `Ventas` y `Costo` sean medidas numéricas. Usa `Linea` como identificador de cada fila y `Pedido` para contar pedidos distintos.

Conserva los archivos `clientes.csv`, `metas.csv` y `leads.csv` para los ejemplos que los pidan.

**Preparación y convenciones de práctica**

- Conecta `ventas.csv` con **Connect > Text File**. Comprueba los tipos en Data Source; convierte `Linea` a dimensión para usarlo como identificador. En cada ejemplo empieza con una hoja nueva sin filtros, salvo que se indique lo contrario. Los demás archivos se conectan solo cuando se mencionan. No uses una unión física previa para los ejemplos de una sola tabla.
- Para los ejemplos de fórmulas: **Analysis > Create Calculated Field**, escribe la expresión y confirma. Si el ejemplo indica una línea, coloca `Linea` como dimensión discreta en Rows, el cálculo en Text (Marks) y consulta la línea indicada; si es un agregado sin dimensiones, colócalo directamente en Text. Si indica una vista por región, mes, producto u otra dimensión, coloca esa dimensión en Rows y el cálculo en Text, salvo instrucciones específicas. Para cálculos de tabla configura el direccionamiento indicado. Los agregados calculados se muestran como `AGG` cuando corresponde.
- En los ejemplos, `Mes venta` es el campo calculado `DATETRUNC('month', [Fecha])`, `Beneficio` es `[Ventas]-[Costo]`, y `Margen` es `SUM([Beneficio])/SUM([Ventas])` (formato Percentage). Crea estos campos cuando aparezcan por primera vez. Para datos completados filtra `Estado = Completado` salvo si la fórmula ya lo hace.
- Totales de control sin filtros: 8 líneas, 7 pedidos distintos, 4 clientes compradores, ventas 1750, costo 1110, beneficio 640, 11 unidades. Norte 700, Sur 1050. Enero 600, febrero 250, marzo 900. Completados: 7 líneas, 6 pedidos, ventas 1700. Los resultados no implican orden de filas salvo que se indique. Las hojas con relaciones o joins deben construirse en fuentes separadas para no alterar estos controles.
